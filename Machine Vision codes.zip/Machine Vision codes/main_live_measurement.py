"""FINAL LIVE DEMO - Automated Object Dimension Measurement.

Workflow required by the assignment:
Webcam -> resize -> grayscale -> Gaussian blur -> Canny (diagnostic) ->
Otsu threshold -> morphology -> contour detection -> calibration -> cm output.

Controls
--------
C : calibrate using the largest visible reference object
R : reset calibration
S : save current measurement snapshot to CSV
D : toggle debug windows (Canny / binary)
Q or ESC : quit

Calibration procedure
---------------------
1. Fix the webcam in a top-down position and do NOT move it afterward.
2. Put ONLY the known reference card on the white surface.
3. Edit REFERENCE_WIDTH_CM / REFERENCE_HEIGHT_CM below if needed.
4. Press C.
5. Remove the card and place target objects. Dimensions appear live in cm.
"""

import cv2

from image_processing import (
    resize_image,
    convert_to_grayscale,
    apply_gaussian_blur,
    apply_canny,
    apply_threshold,
    apply_morphology,
)
from praveen_object_detection import detect_objects
from measurement_utils import (
    calculate_pixels_per_cm,
    measure_objects,
    draw_live_measurements,
    draw_reference_candidate,
    save_measurements_csv,
)

# ------------------------------ SETTINGS ------------------------------
CAMERA_INDEX = 1
MIN_AREA = 1000

# Reference card used in Kisha's notebook: short side x long side.
REFERENCE_WIDTH_CM = 5.4
REFERENCE_HEIGHT_CM = 8.6

CSV_OUTPUT = "live_measurements.csv"


def preprocess_frame(frame):
    image = resize_image(frame)
    gray = convert_to_grayscale(image)
    blurred = apply_gaussian_blur(gray)
    edges = apply_canny(blurred)  # included to demonstrate the required edge step
    binary = apply_threshold(blurred)
    cleaned = apply_morphology(binary)
    return image, gray, blurred, edges, binary, cleaned


def select_reference_object(objects):
    """Use the largest valid object as the calibration reference candidate."""
    if not objects:
        return None
    return max(objects, key=lambda obj: obj.get("area", 0))


def add_status(frame, pixels_per_cm, debug_enabled):
    if pixels_per_cm is None:
        line1 = "NOT CALIBRATED - place reference card alone and press C"
        line2 = f"Reference: {REFERENCE_WIDTH_CM:.1f} x {REFERENCE_HEIGHT_CM:.1f} cm"
        color = (0, 0, 255)
    else:
        line1 = f"CALIBRATED: {pixels_per_cm:.2f} px/cm"
        line2 = "C=recalibrate  R=reset  S=save CSV  D=debug  Q=quit"
        color = (0, 255, 0)

    cv2.rectangle(frame, (10, frame.shape[0] - 70), (frame.shape[1] - 10, frame.shape[0] - 10), (0, 0, 0), -1)
    cv2.putText(frame, line1, (20, frame.shape[0] - 43), cv2.FONT_HERSHEY_SIMPLEX, 0.58, color, 2)
    cv2.putText(frame, line2, (20, frame.shape[0] - 18), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (255, 255, 255), 1)
    if debug_enabled:
        cv2.putText(frame, "DEBUG ON", (frame.shape[1] - 125, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)
    return frame


def main():
    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        raise RuntimeError(
            "Unable to open webcam. Try changing CAMERA_INDEX from 0 to 1."
        )

    pixels_per_cm = None
    debug_enabled = False
    last_measurements = []

    print("=" * 68)
    print("FINAL LIVE OBJECT DIMENSION MEASUREMENT")
    print("=" * 68)
    print("1) Keep webcam fixed top-down.")
    print("2) Put ONLY the reference card in view.")
    print(f"3) Reference dimensions: {REFERENCE_WIDTH_CM} x {REFERENCE_HEIGHT_CM} cm")
    print("4) Press C to calibrate, then place test objects.")
    print("C=calibrate | R=reset | S=save CSV | D=debug | Q=quit")
    print("=" * 68)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Cannot read webcam frame.")
            break

        image, gray, blurred, edges, binary, cleaned = preprocess_frame(frame)
        objects = detect_objects(cleaned, min_area=MIN_AREA)

        if pixels_per_cm is None:
            display = image.copy()
            reference_candidate = select_reference_object(objects)
            if reference_candidate is not None:
                display = draw_reference_candidate(
                    display,
                    reference_candidate,
                    REFERENCE_WIDTH_CM,
                    REFERENCE_HEIGHT_CM,
                )
            else:
                cv2.putText(
                    display,
                    "No reference object detected",
                    (20, 55),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 0, 255),
                    2,
                )
            last_measurements = []
        else:
            last_measurements = measure_objects(objects, pixels_per_cm)
            display = draw_live_measurements(
                image,
                objects,
                last_measurements,
                method_name="OpenCV Contour / minAreaRect",
            )

        display = add_status(display, pixels_per_cm, debug_enabled)
        cv2.imshow("FINAL - Live Object Dimension Measurement", display)

        if debug_enabled:
            cv2.imshow("Debug - Canny Edges", edges)
            cv2.imshow("Debug - Cleaned Binary", cleaned)
        else:
            # Close debug windows if they were previously open.
            for name in ("Debug - Canny Edges", "Debug - Cleaned Binary"):
                try:
                    cv2.destroyWindow(name)
                except cv2.error:
                    pass

        key = cv2.waitKey(1) & 0xFF

        if key == ord("c"):
            reference_candidate = select_reference_object(objects)
            if reference_candidate is None:
                print("Calibration failed: no object detected.")
                continue

            try:
                ppcm, ppcm_w, ppcm_h = calculate_pixels_per_cm(
                    reference_candidate,
                    REFERENCE_WIDTH_CM,
                    REFERENCE_HEIGHT_CM,
                )
                pixels_per_cm = ppcm
                print("\nCALIBRATION SUCCESSFUL")
                print(f"Reference width : {reference_candidate['width_pixels']:.2f} px -> {ppcm_w:.2f} px/cm")
                print(f"Reference height: {reference_candidate['height_pixels']:.2f} px -> {ppcm_h:.2f} px/cm")
                print(f"Average scale   : {pixels_per_cm:.2f} px/cm")
                print("Do not move the webcam after calibration.\n")
            except ValueError as exc:
                print(f"Calibration failed: {exc}")

        elif key == ord("r"):
            pixels_per_cm = None
            last_measurements = []
            print("Calibration reset. Put the reference card alone in view and press C.")

        elif key == ord("s"):
            if pixels_per_cm is None:
                print("Cannot save: calibrate first.")
            elif not last_measurements:
                print("Cannot save: no target object detected.")
            else:
                print("\nMEASUREMENT SNAPSHOT")
                print("=" * 50)

                for measurement in last_measurements:
                    print(
                        f"Object {measurement['object_id']}: "
                        f"Width = {measurement['width_cm']:.2f} cm, "
                        f"Height = {measurement['height_cm']:.2f} cm"
                    )

                print("=" * 50)

                output = save_measurements_csv(
                    last_measurements,
                    csv_path=CSV_OUTPUT,
                    method="Contour-minAreaRect",
                )
                print(f"Measurement snapshot saved to: {output}")

        elif key == ord("d"):
            debug_enabled = not debug_enabled
            print(f"Debug windows: {'ON' if debug_enabled else 'OFF'}")

        elif key == ord("q") or key == 27:
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
