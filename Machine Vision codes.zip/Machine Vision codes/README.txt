FINAL OBJECT DIMENSION MEASUREMENT PROJECT
==========================================

FILES
-----
image_processing.py
    Person 1 preprocessing: resize, grayscale, blur, Canny, Otsu threshold,
    morphology.

praveen_object_detection.py
    Person 2 contour/minAreaRect detector. Rotation-aware pixel dimensions.

praveen_regionprops_detection.py
    Person 2 second method using connected components + skimage regionprops.

measurement_utils.py
    Added integration layer: calibration, px->cm conversion, live labels, CSV.

main_live_measurement.py
    FINAL LIVE DEMO. This is the main file to present to the lecturer.

compare_detection_methods.py
    Live contour vs regionprops comparison for report/presentation evidence.

error_analysis.py
    Calculates Absolute Error and Percentage Relative Error after actual
    ruler/caliper dimensions are entered in live_measurements.csv.

SETUP
-----
Install packages:
    pip install opencv-python numpy scikit-image

Keep every .py file in the SAME folder.

LIVE DEMO
---------
1. Fix webcam perpendicular/top-down above white paper.
2. Do not move camera once calibration is completed.
3. Put ONLY a known 5.4 cm x 8.6 cm reference card in the frame.
4. Run:
       python main_live_measurement.py
5. Press C to calibrate.
6. Remove the reference card and put target object(s) on the paper.
7. Width and height appear live in cm.

KEYS
----
C = calibrate / recalibrate
R = reset calibration
S = save current measured objects to live_measurements.csv
D = toggle Canny + cleaned-binary debug windows
Q or ESC = quit

IF CAMERA DOES NOT OPEN
-----------------------
Change CAMERA_INDEX = 0 to CAMERA_INDEX = 1 in main_live_measurement.py.

IMPORTANT CALIBRATION RULE
--------------------------
If your reference object is not 5.4 cm x 8.6 cm, change:
    REFERENCE_WIDTH_CM = 5.4
    REFERENCE_HEIGHT_CM = 8.6
Use the short physical side as width and long physical side as height.

10-OBJECT VALIDATION
--------------------
For each test object:
1. Display object and press S.
2. Repeat until at least 10 different objects have been tested.
3. Open live_measurements.csv.
4. Enter actual_width_cm and actual_height_cm measured using ruler/caliper.
5. Run:
       python error_analysis.py
6. Use validation_results.csv in the report table.

REPORT EVIDENCE TO CAPTURE
--------------------------
- Original live frame.
- Canny edge window (press D).
- Cleaned binary window (press D).
- Final live bounding box with W/H in cm.
- Contour vs Regionprops comparison window.
- >=10 object validation/error table.

NOTE
----
Thresholding uses THRESH_BINARY_INV, so it is designed mainly for darker
objects on a bright/white reference surface, matching the project setup.
