import cv2

from skimage.measure import label, regionprops


# ============================================================
# SETTINGS
# ============================================================

MIN_AREA = 1000
MAX_AREA_RATIO = 0.50
BORDER_MARGIN = 2


# ============================================================
# REGIONPROPS / CONNECTED COMPONENT DETECTION
# ============================================================

def detect_objects_regionprops(
    binary_image,
    min_area=MIN_AREA
):

    # Convert OpenCV 0/255 image to True/False
    binary_bool = binary_image > 0


    # --------------------------------------------------------
    # CONNECTED COMPONENT LABELLING
    # --------------------------------------------------------

    label_image = label(
        binary_bool,
        connectivity=1,
        background=0
    )


    objects = []

    image_height, image_width = binary_image.shape[:2]
    image_area = image_height * image_width


    for region in regionprops(label_image):

        area = region.area


        # ----------------------------------------------------
        # 1. REMOVE SMALL NOISE
        # ----------------------------------------------------

        if area < min_area:
            continue


        # ----------------------------------------------------
        # 2. REMOVE VERY LARGE BACKGROUND
        # ----------------------------------------------------

        if area > image_area * MAX_AREA_RATIO:
            continue


        # Regionprops bounding box
        minr, minc, maxr, maxc = region.bbox

        width = maxc - minc
        height = maxr - minr


        # ----------------------------------------------------
        # 3. IGNORE OBJECTS TOUCHING IMAGE BORDER
        # ----------------------------------------------------

        if (
            minc <= BORDER_MARGIN
            or minr <= BORDER_MARGIN
            or maxc >= image_width - BORDER_MARGIN
            or maxr >= image_height - BORDER_MARGIN
        ):
            continue


        # ----------------------------------------------------
        # 4. SAVE OBJECT INFORMATION
        # ----------------------------------------------------

        objects.append({

            "label": region.label,

            "area": area,

            "x": minc,
            "y": minr,

            "width_pixels": width,
            "height_pixels": height,

            "major_axis": region.axis_major_length,
            "minor_axis": region.axis_minor_length,

            "centroid": region.centroid,

            "center_x": region.centroid[1],
            "center_y": region.centroid[0]
        })


    # --------------------------------------------------------
    # SORT LEFT → RIGHT
    # --------------------------------------------------------

    objects.sort(
        key=lambda obj: obj["center_x"]
    )


    return objects


# ============================================================
# DRAW REGIONPROPS RESULTS
# ============================================================

def draw_regionprops_boxes(image, objects):

    output = image.copy()


    for number, obj in enumerate(objects, start=1):

        x = obj["x"]
        y = obj["y"]

        w = obj["width_pixels"]
        h = obj["height_pixels"]


        cv2.rectangle(
            output,
            (x, y),
            (x + w, y + h),
            (255, 0, 0),
            2
        )


        cv2.putText(
            output,
            f"Regionprops Object {number}",
            (x, max(y - 30, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 0, 0),
            2
        )


        cv2.putText(
            output,
            f"W:{w:.0f}px H:{h:.0f}px",
            (x, max(y - 8, 40)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 255),
            2
        )


    return output