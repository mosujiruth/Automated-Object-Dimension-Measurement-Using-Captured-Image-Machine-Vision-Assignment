"""LIVE COMPARISON: contour vs regionprops, with centimetre calibration.

This is for the report/presentation comparison. For the cleanest final demo,
run main_live_measurement.py instead.

Controls: C calibrate, R reset, S print comparison, Q quit.
Calibrate with only the known reference card visible.
"""

import cv2
import numpy as np

from image_processing import (
    resize_image,
    convert_to_grayscale,
    apply_gaussian_blur,
    apply_threshold,
    apply_morphology,
)
from praveen_object_detection import detect_objects
from praveen_regionprops_detection import detect_objects_regionprops
from measurement_utils import calculate_pixels_per_cm, measure_objects, draw_live_measurements

CAMERA_INDEX = 0
MIN_AREA = 1000
REFERENCE_WIDTH_CM = 5.4
REFERENCE_HEIGHT_CM = 8.6


def preprocess(frame):
    image = resize_image(frame)
    gray = convert_to_grayscale(image)
    blurred = apply_gaussian_blur(gray)
    binary = apply_threshold(blurred)
    cleaned = apply_morphology(binary)
    return image, cleaned


def largest(objects):
    return max(objects, key=lambda x: x.get("area", 0)) if objects else None


def main():
    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        raise RuntimeError("Unable to open webcam. Try CAMERA_INDEX = 1.")

    pixels_per_cm = None

    print("Contour vs Regionprops - live comparison")
    print("Place ONLY reference card, press C.  R=reset  S=print  Q=quit")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        image, cleaned = preprocess(frame)
        contour_objects = detect_objects(cleaned, min_area=MIN_AREA)
        region_objects = detect_objects_regionprops(cleaned, min_area=MIN_AREA)

        if pixels_per_cm is None:
            left = image.copy()
            right = image.copy()
            cv2.putText(left, "Contour - press C to calibrate", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 255), 2)
            cv2.putText(right, "Regionprops - not calibrated", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 255), 2)
            contour_measurements = []
            region_measurements = []
        else:
            contour_measurements = measure_objects(contour_objects, pixels_per_cm)
            region_measurements = measure_objects(region_objects, pixels_per_cm)
            left = draw_live_measurements(image, contour_objects, contour_measurements, "Contour")
            right = draw_live_measurements(image, region_objects, region_measurements, "Regionprops")

        comparison = np.hstack((left, right))
        cv2.imshow("LIVE - Contour vs Regionprops", comparison)
        cv2.imshow("Cleaned Binary", cleaned)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("c"):
            ref = largest(contour_objects)
            if ref is None:
                print("Calibration failed: no contour object detected.")
            else:
                pixels_per_cm, pw, ph = calculate_pixels_per_cm(
                    ref, REFERENCE_WIDTH_CM, REFERENCE_HEIGHT_CM
                )
                print(f"Calibrated: {pixels_per_cm:.2f} px/cm (W={pw:.2f}, H={ph:.2f})")

        elif key == ord("r"):
            pixels_per_cm = None
            print("Calibration reset.")

        elif key == ord("s"):
            if pixels_per_cm is None:
                print("Calibrate first.")
                continue
            print("\n" + "=" * 72)
            print(f"Contour objects    : {len(contour_measurements)}")
            print(f"Regionprops objects: {len(region_measurements)}")
            matched = min(len(contour_measurements), len(region_measurements))
            for i in range(matched):
                c = contour_measurements[i]
                r = region_measurements[i]
                print(f"Object {i+1}")
                print(f"  Contour    : W={c['width_cm']:.2f} cm H={c['height_cm']:.2f} cm")
                print(f"  Regionprops: W={r['width_cm']:.2f} cm H={r['height_cm']:.2f} cm")
                print(f"  Difference : W={abs(c['width_cm']-r['width_cm']):.2f} cm H={abs(c['height_cm']-r['height_cm']):.2f} cm")
            print("=" * 72)

        elif key == ord("q") or key == 27:
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
