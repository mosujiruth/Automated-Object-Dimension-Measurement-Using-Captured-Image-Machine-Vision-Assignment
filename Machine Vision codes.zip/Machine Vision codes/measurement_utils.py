"""Calibration and real-world dimension measurement utilities.

This module integrates the calibration/measurement idea from Kisha's notebook
with the live contour/regionprops detectors used by the group project.
"""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np


def calculate_pixels_per_cm(reference_object, reference_width_cm, reference_height_cm):
    """Calculate a single pixels-per-centimetre scale from a known rectangle.

    The contour detector stores the short side as width_pixels and the long side
    as height_pixels. Therefore the physical reference dimensions should also be
    supplied short-side first, long-side second (e.g. 5.4 cm x 8.6 cm).
    """
    if reference_width_cm <= 0 or reference_height_cm <= 0:
        raise ValueError("Reference dimensions must be greater than 0.")

    width_px = float(reference_object["width_pixels"])
    height_px = float(reference_object["height_pixels"])
    if width_px <= 0 or height_px <= 0:
        raise ValueError("Detected reference dimensions must be greater than 0 pixels.")

    ppcm_w = width_px / float(reference_width_cm)
    ppcm_h = height_px / float(reference_height_cm)
    ppcm = (ppcm_w + ppcm_h) / 2.0

    return ppcm, ppcm_w, ppcm_h


def measure_objects(objects: Iterable[dict], pixels_per_cm: float):
    """Convert every detected object's pixel dimensions to centimetres."""
    if pixels_per_cm <= 0:
        raise ValueError("pixels_per_cm must be greater than 0.")

    measurements = []
    for number, obj in enumerate(objects, start=1):
        width_px = float(obj["width_pixels"])
        height_px = float(obj["height_pixels"])
        measurements.append(
            {
                "object_id": number,
                "width_pixels": width_px,
                "height_pixels": height_px,
                "width_cm": width_px / pixels_per_cm,
                "height_cm": height_px / pixels_per_cm,
                "area_pixels": float(obj.get("area", 0)),
            }
        )
    return measurements


def _label_origin(obj):
    if "box" in obj:
        box = np.asarray(obj["box"], dtype=np.int32)
        return int(np.min(box[:, 0])), int(np.min(box[:, 1]))
    return int(obj["x"]), int(obj["y"])


def draw_live_measurements(image, objects, measurements, method_name="Contour"):
    """Draw boxes and live centimetre measurements on a frame."""
    output = image.copy()

    for obj, m in zip(objects, measurements):
        if "box" in obj:
            box = np.asarray(obj["box"], dtype=np.int32)
            cv2.drawContours(output, [box], 0, (0, 255, 0), 2)
        else:
            x, y = int(obj["x"]), int(obj["y"])
            w, h = int(round(obj["width_pixels"])), int(round(obj["height_pixels"]))
            cv2.rectangle(output, (x, y), (x + w, y + h), (255, 0, 0), 2)

        x, y = _label_origin(obj)
        cv2.putText(
            output,
            f"Object {m['object_id']}",
            (x, max(y - 32, 24)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.58,
            (0, 255, 0),
            2,
        )
        cv2.putText(
            output,
            f"W:{m['width_cm']:.2f} cm  H:{m['height_cm']:.2f} cm",
            (x, max(y - 9, 46)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.52,
            (0, 255, 255),
            2,
        )

    cv2.putText(
        output,
        f"Method: {method_name} | Objects: {len(measurements)}",
        (20, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.68,
        (255, 255, 255),
        2,
    )
    return output


def draw_reference_candidate(image, reference_object, reference_w_cm, reference_h_cm):
    """Highlight the object that will be used when C is pressed."""
    output = image.copy()
    if "box" in reference_object:
        box = np.asarray(reference_object["box"], dtype=np.int32)
        cv2.drawContours(output, [box], 0, (255, 255, 0), 3)
    else:
        x, y = int(reference_object["x"]), int(reference_object["y"])
        w = int(round(reference_object["width_pixels"]))
        h = int(round(reference_object["height_pixels"]))
        cv2.rectangle(output, (x, y), (x + w, y + h), (255, 255, 0), 3)

    x, y = _label_origin(reference_object)
    cv2.putText(
        output,
        f"REFERENCE {reference_w_cm:.1f} x {reference_h_cm:.1f} cm - press C",
        (max(x, 10), max(y - 10, 25)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 0),
        2,
    )
    return output


def save_measurements_csv(measurements, csv_path="live_measurements.csv", method="Contour"):
    """Append a snapshot to CSV for the report/validation experiment."""
    path = Path(csv_path)
    exists = path.exists()
    timestamp = datetime.now().isoformat(timespec="seconds")

    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "timestamp",
                "method",
                "object_id",
                "width_pixels",
                "height_pixels",
                "measured_width_cm",
                "measured_height_cm",
                "actual_width_cm",
                "actual_height_cm",
                "width_abs_error_cm",
                "height_abs_error_cm",
                "width_percent_error",
                "height_percent_error",
            ],
        )
        if not exists:
            writer.writeheader()

        for m in measurements:
            writer.writerow(
                {
                    "timestamp": timestamp,
                    "method": method,
                    "object_id": m["object_id"],
                    "width_pixels": f"{m['width_pixels']:.2f}",
                    "height_pixels": f"{m['height_pixels']:.2f}",
                    "measured_width_cm": f"{m['width_cm']:.3f}",
                    "measured_height_cm": f"{m['height_cm']:.3f}",
                    "actual_width_cm": "",
                    "actual_height_cm": "",
                    "width_abs_error_cm": "",
                    "height_abs_error_cm": "",
                    "width_percent_error": "",
                    "height_percent_error": "",
                }
            )
    return str(path.resolve())
