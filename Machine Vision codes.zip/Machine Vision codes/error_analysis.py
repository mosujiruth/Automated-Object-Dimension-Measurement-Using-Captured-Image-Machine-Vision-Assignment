"""Calculate absolute and percentage error for the >=10-object experiment.

1. Collect measurements using main_live_measurement.py and press S.
2. Open live_measurements.csv.
3. Fill actual_width_cm and actual_height_cm using a ruler/caliper.
4. Save it.
5. Run: python error_analysis.py

The script writes validation_results.csv with the required error columns.
"""

import csv
from pathlib import Path

INPUT_FILE = Path("live_measurements.csv")
OUTPUT_FILE = Path("validation_results.csv")


def safe_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            "live_measurements.csv not found. Run the live program and press S first."
        )

    with INPUT_FILE.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    completed = []
    for row in rows:
        mw = safe_float(row.get("measured_width_cm"))
        mh = safe_float(row.get("measured_height_cm"))
        aw = safe_float(row.get("actual_width_cm"))
        ah = safe_float(row.get("actual_height_cm"))

        if None in (mw, mh, aw, ah) or aw <= 0 or ah <= 0:
            continue

        w_abs = abs(mw - aw)
        h_abs = abs(mh - ah)
        w_pct = (w_abs / aw) * 100
        h_pct = (h_abs / ah) * 100

        row["width_abs_error_cm"] = f"{w_abs:.3f}"
        row["height_abs_error_cm"] = f"{h_abs:.3f}"
        row["width_percent_error"] = f"{w_pct:.2f}"
        row["height_percent_error"] = f"{h_pct:.2f}"
        completed.append(row)

    if not completed:
        print("No completed rows found. Fill actual_width_cm and actual_height_cm first.")
        return

    fieldnames = list(completed[0].keys())
    with OUTPUT_FILE.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(completed)

    avg_w = sum(float(r["width_percent_error"]) for r in completed) / len(completed)
    avg_h = sum(float(r["height_percent_error"]) for r in completed) / len(completed)

    print(f"Completed test rows: {len(completed)}")
    print(f"Average width percentage error : {avg_w:.2f}%")
    print(f"Average height percentage error: {avg_h:.2f}%")
    print(f"Results saved to: {OUTPUT_FILE.resolve()}")


if __name__ == "__main__":
    main()
