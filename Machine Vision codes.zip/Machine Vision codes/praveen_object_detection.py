import cv2
import numpy as np


# ============================================================
# SETTINGS
# ============================================================

MIN_AREA = 1000
MAX_AREA_RATIO = 0.50
BORDER_MARGIN = 2


# ============================================================
# CONTOUR-BASED OBJECT DETECTION
# ============================================================

def detect_objects(binary_image, min_area=MIN_AREA):

    contours, _ = cv2.findContours(
        binary_image,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    objects = []

    image_height, image_width = binary_image.shape[:2]
    image_area = image_height * image_width


    for contour in contours:

        area = cv2.contourArea(contour)


        # ----------------------------------------------------
        # 1. REMOVE SMALL NOISE
        # ----------------------------------------------------

        if area < min_area:
            continue


        # ----------------------------------------------------
        # 2. REMOVE VERY LARGE BACKGROUND REGIONS
        # ----------------------------------------------------

        if area > image_area * MAX_AREA_RATIO:
            continue


        # ----------------------------------------------------
        # 3. NORMAL BOUNDING BOX
        # ----------------------------------------------------

        x, y, w, h = cv2.boundingRect(contour)


        # ----------------------------------------------------
        # 4. IGNORE REGIONS TOUCHING IMAGE BORDER
        # ----------------------------------------------------

        if (
            x <= BORDER_MARGIN
            or y <= BORDER_MARGIN
            or x + w >= image_width - BORDER_MARGIN
            or y + h >= image_height - BORDER_MARGIN
        ):
            continue


        # ----------------------------------------------------
        # 5. ROTATION-AWARE BOUNDING BOX
        # ----------------------------------------------------

        rect = cv2.minAreaRect(contour)

        (center_x, center_y), (rect_w, rect_h), angle = rect


        if rect_w <= 0 or rect_h <= 0:
            continue


        # Short side = width
        # Long side = height
        rotated_width = min(rect_w, rect_h)
        rotated_height = max(rect_w, rect_h)


        # Get four corners of rotated rectangle
        box = cv2.boxPoints(rect)
        box = np.int32(box)


        # ----------------------------------------------------
        # 6. SAVE OBJECT INFORMATION
        # ----------------------------------------------------

        objects.append({

            "contour": contour,

            "area": area,

            "x": x,
            "y": y,

            # Rotation-aware dimensions
            "width_pixels": rotated_width,
            "height_pixels": rotated_height,

            # Original bounding rectangle values
            "bbox_width": w,
            "bbox_height": h,

            "center_x": center_x,
            "center_y": center_y,

            "angle": angle,

            "box": box
        })


    # --------------------------------------------------------
    # SORT OBJECTS LEFT → RIGHT
    # --------------------------------------------------------

    objects.sort(
        key=lambda obj: obj["center_x"]
    )


    return objects


# ============================================================
# DRAW CONTOUR DETECTION RESULTS
# ============================================================

def draw_bounding_boxes(image, objects):

    output = image.copy()


    for number, obj in enumerate(objects, start=1):

        box = obj["box"]

        width = obj["width_pixels"]
        height = obj["height_pixels"]


        # Rotated bounding box
        cv2.drawContours(
            output,
            [box],
            0,
            (0, 255, 0),
            2
        )


        # Label position
        x = int(min(box[:, 0]))
        y = int(min(box[:, 1]))


        cv2.putText(
            output,
            f"Contour Object {number}",
            (x, max(y - 30, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 0),
            2
        )


        cv2.putText(
            output,
            f"W:{width:.0f}px H:{height:.0f}px",
            (x, max(y - 8, 40)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 255),
            2
        )


    return output