# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 01:47:23 2026

@author: sujidren
"""
import cv2
import numpy as np

min_object_area = 1000
max_image_width = 1200

def load_image(image_path):
    image = cv2.imread(image_path)
    
    if image is None:
        raise FileNotFoundError(
            "unable to load image:"+ image_path)
    return image

def resize_image(image,max_width=max_image_width):
    
    height, width =image.shape[:2]
    
    if width <= max_width:
        return image.copy()
    
    scale=max_width/width
    
    new_width =int(width*scale)
    new_height=int(height*scale)
    
    return cv2.resize(
        image,
        (new_width,new_height),
        interpolation=cv2.INTER_AREA)

def convert_to_grayscale(image):
    
    return cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY)

def apply_gaussian_blur(gray):
    
    return cv2.GaussianBlur(
        gray,(5,5),0)

def apply_canny(
    blurred,
    lower_threshold=50,
    upper_threshold=150
):
    edges = cv2.Canny(
        blurred,
        lower_threshold,
        upper_threshold
    )

    return edges

def apply_threshold(blurred):
    _,binary=cv2.threshold(
        blurred,
        0,
        255,
        cv2.THRESH_BINARY_INV +cv2.THRESH_OTSU)
    
    return binary

def apply_morphology(binary):
    
    kernel =np.ones(
        (5,5),
        np.uint8)
    closed =cv2.morphologyEx(
        binary,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=2)
    cleaned=cv2.morphologyEx(
        closed,
        cv2.MORPH_OPEN,
        kernel,
        iterations=1)
    
    return cleaned

def detect_objects(binary, min_area=min_object_area):
    
    contours,_=cv2.findContours(
        binary,cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE)
    
    objects = []
    
    for contour in contours:
        
        area =cv2.contourArea(contour)
        
        if area <min_area:
            continue
        
        x, y,width, height =cv2.boundingRect(contour)
        
        objects.append({
            "contour":contour,
            "area":area,
            "x":x,
            "y":y,
            "width_pixels":width,
            "height_pixels":height})
        
    objects.sort(
        key=lambda obj :obj["x"])
    
    return objects

def measure_objects(objects,pixels_per_cm):
    if pixels_per_cm <= 0:
        raise ValueError("pixels_per_cm must be greater than 0")

    measurements =[]
    
    for number,obj in enumerate(
            objects,start=1):
        
        width_pixels =obj["width_pixels"]
        height_pixels =obj["height_pixels"]
        
        width_cm = width_pixels / pixels_per_cm
        height_cm = height_pixels / pixels_per_cm
        
        measurements.append({
            "object_id":number,
            "width_pixels":width_pixels,
            "height_pixels":height_pixels,
            "width_cm":width_cm,
            "height_cm":height_cm,
            "area_pixels":obj["area"]})
        
    return measurements

def draw_results(image, objects, measurements):

    result = image.copy()

    for obj, measurement in zip(
        objects,
        measurements
    ):

        x = obj["x"]
        y = obj["y"]

        width = obj["width_pixels"]
        height = obj["height_pixels"]

        cv2.rectangle(
            result,
            (x, y),
            (x + width, y + height),
            (0, 255, 0),
            2
        )

        cv2.putText(
            result,
            f"Object {measurement['object_id']}",
            (x, max(y - 35, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2
        )

        text = (
            f"W: {measurement['width_cm']:.2f} cm "
            f"H: {measurement['height_cm']:.2f} cm"
        )

        cv2.putText(
            result,
            text,
            (x, max(y - 10, 40)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 255),
            2
        )

    return result


def process_image(image_path, pixels_per_cm):

    image = load_image(image_path)

    image = resize_image(image)

    gray = convert_to_grayscale(image)

    blurred = apply_gaussian_blur(gray)

    binary = apply_threshold(blurred)

    cleaned = apply_morphology(binary)

    objects = detect_objects(cleaned)

    measurements = measure_objects(
        objects,
        pixels_per_cm
    )

    result = draw_results(
        image,
        objects,
        measurements
    )

    return {
        "original": image,
        "gray": gray,
        "blurred": blurred,
        "binary": binary,
        "cleaned": cleaned,
        "objects": objects,
        "measurements": measurements,
        "result": result
    }
    
